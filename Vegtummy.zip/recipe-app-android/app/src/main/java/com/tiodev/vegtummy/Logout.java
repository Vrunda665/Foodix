package com.tiodev.vegtummy;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Logout extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logout);

        Button btnLogout = findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(new View.OnClickListener() {
                                         @Override
                                         public void onClick(View view) {
                                             AlertDialog.Builder alert = new AlertDialog.Builder(Logout.this);
                                             alert.setTitle("Alert!!!");
                                             alert.setMessage("Do you really want to Logout ?");
                                             alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                                 @Override
                                                 public void onClick(DialogInterface dialogInterface, int i) {
                                                     Toast.makeText(Logout.this, "Logout Successfull...", Toast.LENGTH_SHORT).show();
                                                     finish();
                                                 }
                                             });
                                             alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                                                 @Override
                                                 public void onClick(DialogInterface dialogInterface, int i) {
                                                     dialogInterface.cancel();
                                                 }
                                             });
                                             alert.create().show();
                                         }
                                     }
        );
    }
}